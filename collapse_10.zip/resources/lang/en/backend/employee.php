<?php

return [
	'employee_view' => 'Employee View',
	'add_employee' => 'Add Employee',
	'edit_employee' => 'Edit Employee',
	'employee_list' => 'Employee List',
];
