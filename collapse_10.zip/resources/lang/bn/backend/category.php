<?php

return [
	'category' => 'ক্যাটাগরি',
	'category_management' => 'ক্যাটাগরি ব্যবস্থাপনা',
	'edit_category' => 'ক্যাটাগরি সম্পাদন'
];
