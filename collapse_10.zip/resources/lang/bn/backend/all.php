<?php

return [
'language_management' => 'ভাষা ব্যাবস্থাপনা',
'add_name' => 'নাম দিন',
'developer' => 'উন্নয়নকারী',
'language' => 'ভাষা',
'add_file' => 'ফাইল যোগ করুন',
'my_admins' => 'এডমিনগণ',
'add_admin' => 'এডমিন যোগ করুন',
	'all_admin' => 'সকল এডমিন',
];
