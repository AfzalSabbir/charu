<?php

return [
	'cost_management' => 'Cost Management',
	'cost' => 'Cost',
	'add_cost' => 'Add Cost',
	'cost_list' => 'Cost List',
	'edit_cost' => 'Edit Cost',
	'cost_title' => 'Cost Title',
];
