<?php

return [
	'add_sale' => 'নতুন বিক্রয়',
	'sale_management' => 'বিক্রয় ব্যাবস্থাপনা',
	'sale_list' => 'বিক্রয় তালিকা',
	'sale' => 'বিক্রয়',
	'view_sale' => 'বিস্তারিত বিল',
	'total_sale' => 'মোট বিক্রি',
	'total_product' => 'মোট পণ্য',
	'edit_sale' => 'ইডিট বিক্রয়',
];
