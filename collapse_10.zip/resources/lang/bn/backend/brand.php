<?php

return [
    'brand' => 'ব্র্যান্ড',
    'brand_management' => 'ব্র্যান্ড ব্যবস্থাপনা',
    'edit_brand' => 'এডিট ব্র্যান্ড',
    'add_brand' => 'নতুন ব্র্যান্ড'
];