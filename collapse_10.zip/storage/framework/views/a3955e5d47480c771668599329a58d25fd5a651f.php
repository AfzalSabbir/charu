<!DOCTYPE html>
<html class="no-js" lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->make('frontend.partials.metas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startSection('metas'); ?>
    <?php echo $__env->yieldSection(); ?>

    <title><?php echo $__env->yieldContent('fav_title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('public/js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=BioRhyme:200,300,400,700,800%7CCutive%7CKadwa:400,700%7CKreon:300,400,700%7CMarko+One%7CPodkova:400,500,600,700,800%7CRhodium+Libre%7CSanchez:400,400i%7CSuez+One%7CUltra%7COxygen+Mono%7COxygen:300,400,700%7CMontserrat+Alternates:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i%7CMontserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i%7CAlex+Brush%7CCaveat+Brush%7CChela+One%7CMaven+Pro:400,500,700,900%7CArvo:400,400i,700,700i%7CLato:100,100i,300,300i,400,400i,700,700i,900,900i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet" type="text/css">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link rel="icon" href="<?php echo e(asset('public/img/printing-service.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/reset.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/reset-media.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/app.css')); ?>">

    <?php echo $__env->make('frontend.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startSection('styles'); ?>
    <?php echo $__env->yieldSection(); ?>

</head>
<body>
    <div id="app">
        

        <main class="py-4">
            
            <?php if(\Route::current()->getName() != 'contact_us'): ?>
                <?php echo $__env->make('frontend.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('frontend.partials.nav2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php $__env->startSection('content'); ?>
            <?php echo $__env->yieldSection(); ?> 
            <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </main>
    </div>

    <?php echo $__env->make('frontend.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->startSection('scripts'); ?>
    <?php echo $__env->yieldSection(); ?>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\charu\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>