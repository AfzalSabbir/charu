<?php

return [
	'new_password' => 'New Password',
	'old_password' => 'Old Password',
	'confirm_password' => 'Confirm Password',
];
