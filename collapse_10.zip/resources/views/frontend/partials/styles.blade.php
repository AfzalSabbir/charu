<link rel="stylesheet" href="{{ asset('public/css/vcard-offer.css') }}">
<link rel="stylesheet" href="{{ asset('public/css/printing-offer.css') }}">
<link rel="stylesheet" href="{{ asset('public/css/a_custom.css') }}">