<?php

return [
	'menu' => 'মেনু',
	'menu_management' => 'মেনু ব্যবস্থাপনা',
	'menu_list' => 'মেনু তালিকা',
	'add_menu' => 'মেনু সংযোজন',
	'edit_menu' => 'মেনু সম্পাদনা',
	'delete_menu' => 'ডিলিট মেনু',
	'permission_management' => 'অনুমতি ব্যাবস্থাপনা',
	'menu_permission' => 'মেনু অনুমতি',
	'submenu' => 'সাবমেনু',
];
