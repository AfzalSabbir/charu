<?php

return [
	'root_management' => 'মূল ব্যাবস্থাপনা',
	'employee_list' => 'কর্মচারী তালিকা',
];
