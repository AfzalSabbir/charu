<?php

return [
	'add_message' => 'Added successfully !!!',
	'update_message' => 'Updated successfully !!!',
	'delete_message' => 'Deleted successfully !!!',
	'deactive_message' => 'Deactivated Successfully !!!',
	'exist_message' => 'Already Exists !!!',
];
