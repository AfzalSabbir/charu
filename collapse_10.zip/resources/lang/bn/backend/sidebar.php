<?php

return [
	'dashboard' => 'ড্যাশবোর্ড',
	'menu' => 'মেনু',
	'add_menu' => 'মেনু সংযোজন',
	'menu_list' => 'মেনু তালিকা',
	'logout' => 'লগ আউট',
	'hello' => 'হ্যালো',
	'assign' => 'দায়িত্ব অর্পণ',
];
