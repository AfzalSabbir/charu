<?php

return [
    'brand' => 'Brand',
    'brand_management' => 'Brand Management',
    'edit_brand' => 'Edit Brand',
    'add_brand' => 'Add Brand'
];