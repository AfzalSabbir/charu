<?php
    //$created = ucwords(preg_replace("/[\-_]/", " ",  $created));
    $created_ = strtolower(preg_replace("/[\s+]/", "_", $created));
    // $created = preg_replace("/[\s+]/", "", $created);
	$CreateD = preg_replace("/[\s+]/", "", ucwords(preg_replace("/[\-_]/", " ",  $created)));
?>
&lt;?php<br><br>
<br>
namespace App\Http\Controllers\Backend;<br>
<br>
use Illuminate\Http\Request;<br>
use App\Http\Controllers\Controller;<br>
use App\Helpers\ImageUploadHelper;<br>
use App\Helpers\QueryHelper;<br>
use App\Helpers\StringHelper;<br>
use App\Helpers\NumberHelper;<br>
use App\Models\<?php echo e($CreateD); ?>;<br>
<br>
class <?php echo e($CreateD); ?>Controller extends Controller<br>
{<br><br>
<?php echo $tab; ?>/**<br>
<?php echo $tab; ?> * Site Access<br>
<?php echo $tab; ?>**/<br>
<?php echo $tab; ?>public function __construct()<br>
<?php echo $tab; ?>{<br>
<?php echo $tab; ?><?php echo $tab; ?>&dollar;this->middleware('auth:admin');<br>
<?php echo $tab; ?>}<br>

<?php if($type_ == 'oneClickAll'): ?><br>
<?php echo $tab; ?>public function index()<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>//&dollar;rows = <?php echo e($CreateD); ?>::orderBy('status', 'desc')->orderBy('id', 'desc')->get();<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.index'/*, compact('rows')*/);<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function add()<br>
<?php echo $tab; ?>{<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.add');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function store(Request &dollar;request)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>&dollar;this->validate(&dollar;request, [<br>
<?php echo $tab; ?><?php echo $tab; ?><?php echo $tab; ?>'' => '',<br>
<?php echo $tab; ?><?php echo $tab; ?>]);<br>
<?php echo $tab.$tab; ?>&dollar;data = &dollar;request->except(['_token']);<br>
<?php echo $tab; ?><?php echo $tab; ?>QueryHelper::simpleInsert('<?php echo e($CreateD); ?>', &dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('add_message', 'Added');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function edit(&dollar;id)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>//&dollar;row = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.edit'/*, compact('row')*/);<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function update(Request &dollar;request, &dollar;id)<br>
<?php echo $tab; ?>{<br>  
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?> = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab.$tab; ?>&dollar;this->validate(&dollar;request, [<br>
<?php echo $tab; ?><?php echo $tab; ?><?php echo $tab; ?>'' => '',<br>
<?php echo $tab; ?><?php echo $tab; ?>]);<br>
<?php echo $tab.$tab; ?>&dollar;data = &dollar;request->except(['_token']);<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?>->update(&dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('update_message', 'Added');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function delete(&dollar;id)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?> = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab.$tab; ?>&dollar;data['status'] = 0;<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?>->update(&dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('deactive_message', 'Deactived');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br>
}<br>
<?php elseif($type_ == 'oneClickAllWithView'): ?><br>
<?php echo $tab; ?>public function index()<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>//&dollar;rows = <?php echo e($CreateD); ?>::orderBy('status', 'desc')->orderBy('id', 'desc')->get();<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.index'/*, compact('rows')*/);<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function add()<br>
<?php echo $tab; ?>{<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.add');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function store(Request &dollar;request)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>&dollar;this->validate(&dollar;request, [<br>
<?php echo $tab; ?><?php echo $tab; ?><?php echo $tab; ?>'' => '',<br>
<?php echo $tab; ?><?php echo $tab; ?>]);<br>
<?php echo $tab.$tab; ?>&dollar;data = &dollar;request->except(['_token']);<br>
<?php echo $tab; ?><?php echo $tab; ?>QueryHelper::simpleInsert('<?php echo e($CreateD); ?>', &dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('add_message', 'Added');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function view(&dollar;id)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>//&dollar;row = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e(($created)); ?>.view'/*, compact('row')*/);<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function edit(&dollar;id)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>//&dollar;row = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.edit'/*, compact('row')*/);<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function update(Request &dollar;request, &dollar;id)<br>
<?php echo $tab; ?>{<br>  
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?> = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab.$tab; ?>&dollar;this->validate(&dollar;request, [<br>
<?php echo $tab; ?><?php echo $tab; ?><?php echo $tab; ?>'' => '',<br>
<?php echo $tab; ?><?php echo $tab; ?>]);<br>
<?php echo $tab.$tab; ?>&dollar;data = &dollar;request->except(['_token']);<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?>->update(&dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('update_message', 'Added');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function delete(&dollar;id)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?> = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab.$tab; ?>&dollar;data['status'] = 0;<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?>->update(&dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('deactive_message', 'Deactived');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br>
}<br>
<?php elseif($type_ == 'model'): ?>
<?php echo $tab; ?>public function index()<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>//&dollar;rows = <?php echo e($CreateD); ?>::orderBy('status', 'desc')->orderBy('id', 'desc')->get();<br>
<?php echo $tab; ?><?php echo $tab; ?>return view('backend.pages.<?php echo e($created); ?>.index'/*, compact('rows')*/);<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function store(Request &dollar;request)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>&dollar;this->validate(&dollar;request, [<br>
<?php echo $tab; ?><?php echo $tab; ?><?php echo $tab; ?>'' => '',<br>
<?php echo $tab; ?><?php echo $tab; ?>]);<br>
<?php echo $tab.$tab; ?>&dollar;data = &dollar;request->except(['_token']);<br>
<?php echo $tab; ?><?php echo $tab; ?>QueryHelper::simpleInsert('<?php echo e($CreateD); ?>', &dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('add_message', 'Added');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function update(Request &dollar;request, &dollar;id)<br>
<?php echo $tab; ?>{<br>  
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?> = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab.$tab; ?>&dollar;this->validate(&dollar;request, [<br>
<?php echo $tab; ?><?php echo $tab; ?><?php echo $tab; ?>'' => '',<br>
<?php echo $tab; ?><?php echo $tab; ?>]);<br>
<?php echo $tab.$tab; ?>&dollar;data = &dollar;request->except(['_token']);<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?>->update(&dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('update_message', 'Added');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br><br>

<?php echo $tab; ?>public function delete(&dollar;id)<br>
<?php echo $tab; ?>{<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?> = <?php echo e($CreateD); ?>::where('id', &dollar;id)->first();<br>
<?php echo $tab.$tab; ?>&dollar;data['status'] = 0;<br>
<?php echo $tab.$tab; ?>&dollar;<?php echo e($created); ?>->update(&dollar;data);<br>
<?php echo $tab; ?><?php echo $tab; ?>session()->flash('deactive_message', 'Deactived');<br>
<?php echo $tab; ?><?php echo $tab; ?>return redirect()->route('admin.<?php echo e($created); ?>.index');<br>
<?php echo $tab; ?>}<br>
}<br>
<?php else: ?>
}<br>
<script type="text/javascript">
    $('.text_2-container').hide();
</script>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\admin5-8\resources\views/backend/pages/root/controller.blade.php ENDPATH**/ ?>