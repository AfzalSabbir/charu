<?php

return [
	'cost_management' => 'খরচ ব্যাবস্থাপনা',
	'cost' => 'খরচ',
	'add_cost' => 'খরচ যোগ করুন',
	'cost_list' => 'খরচ তালিকা',
	'edit_cost' => 'খরচ সম্পাদনা',
	'cost_title' => 'খরচের টাইটেল',
];
