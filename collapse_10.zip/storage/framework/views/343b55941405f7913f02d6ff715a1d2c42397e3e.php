<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <?php
  $site_setting = \App\Models\Setting::first();
  ?>

  <link rel="icon" href="<?php echo asset($site_setting->favicon); ?>" type="image/gif" sizes="16x16"> 

  <title><?php echo e(Config::get('app.locale') == 'en' ? ucwords($site_setting->title_en) : $site_setting->title_bn); ?> - <?php echo $__env->yieldContent('fav_title'); ?></title>

  <?php echo $__env->make('backend.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <style>
    .preloader {
     position: absolute;
     top: 0;
     left: 0;
     width: 100%;
     height: 100%;
     z-index: 9999;
     background-image: "<?php echo e(asset('public/5.gif')); ?>";
     background-repeat: no-repeat; 
     background-color: #FFF;
     background-position: center;
   }
   .toast-top-right {
     top: 50px !important;
     right: 31px !important;
   }
   [v-cloak] .v-cloak--block {
    display: block;
  }
  [v-cloak] .v-cloak--inline {
    display: inline;
  }
  [v-cloak] .v-cloak--inlineBlock {
    display: inline-block;
  }
  [v-cloak] .v-cloak--hidden {
    display: none;
  }
  [v-cloak] .v-cloak--invisible {
    visibility: hidden;
  }
  .v-cloak--block,
  .v-cloak--inline,
  .v-cloak--inlineBlock {
    display: none;
  }
  i.fa.fa-spinner.fa-pulse.fa-3x.fa-fw {
    margin-left: 46%;
    bottom: 50%;
    margin-top: 11%;
  }
  .loader{
    margin-left: 46%;
    bottom: 50%;
    margin-top: 11%;
  }
</style>

<?php $__env->startSection('styles'); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('backend.partials.permission', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="app sidebar-mini rtl">

  

  <?php echo $__env->make('backend.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('backend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div id="main-wrapper">

    <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="app-content" id="app">

      <div v-cloak>
        <div class="v-cloak--inline">
          
          <img class="loader" src="http://smallenvelop.com/wp-content/uploads/2014/08/Preloader_2.gif" alt="">
        </div>

        <div class="v-cloak--hidden"> 
          <init 
          :auth_id="<?php echo e(Auth::guard('admin')->user()->id); ?>"
          domain="<?php echo e(url('/')); ?>"
          :default_lang="<?php echo e(json_encode(Lang::get('backend/default'))); ?>"
          :file_form_field="<?php echo e(json_encode(Lang::get('backend/form_field'))); ?>"
          :file_table="<?php echo e(json_encode(Lang::get('backend/table'))); ?>"
          ></init>

          <?php $__env->startSection('content'); ?>
          <?php echo $__env->yieldSection(); ?>   
        </div>
      </div>
    </main>

  </div>

  <?php echo $__env->make('backend.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php $__env->startSection('scripts'); ?>
  <?php echo $__env->yieldSection(); ?>

  
</body>
</html><?php /**PATH E:\xampp\htdocs\admin5-8\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>