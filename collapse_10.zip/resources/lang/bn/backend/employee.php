<?php

return [
	'employee_view' => 'কর্মচারী দেখুন',
	'add_employee' => 'কর্মচারী যোগ করুন',
	'edit_employee' => 'কর্মচারী সম্পাদনা করুন',
	'employee_list' => 'কর্মচারী তালিকা',
];
