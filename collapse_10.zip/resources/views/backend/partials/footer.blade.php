<footer class="footer text-center">
	All Rights Reserved by FreelanceITLab
	<a href="">FreelanceITLab</a>.
</footer>
