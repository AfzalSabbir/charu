<?php

return [
	'dashboard' => 'Dashboard',
	'menu'      => 'Menu',
	'add_menu'  => 'Add Menu',
	'menu_list'  => 'Menu List',
	'logout'  => 'Logout',
	'hello'  => 'Hello',
	'assign' => 'Assign',
];
