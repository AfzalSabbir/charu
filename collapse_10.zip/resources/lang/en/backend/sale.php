<?php

return [
	'add_sale' => 'Add Sale',
	'sale_management' => 'Sale Management',
	'sale_list' => 'Sale List',
	'sale' => 'Sale',
	'view_sale' => 'Bill Details',
	'total_sale' => 'Total Sale',
	'total_product' => 'Total Product',
	'edit_sale' => 'Edit Sale',
];
