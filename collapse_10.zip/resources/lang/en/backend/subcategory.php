<?php

return [
    'subcategory' => 'Subcategory',
    'subcategory_management' => 'Subcategory Management',
    'add_subcategory' => 'Add Subcategory',
    'edit_subcategory' => 'Edit Subcategory',
    'subcategory_list' => 'Subcategory List'
];