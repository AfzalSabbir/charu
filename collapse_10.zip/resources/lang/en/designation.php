<?php

return [
    'designation_management' => 'Designation Management',
    'designation' => 'Designation',
    'add_designation' => 'Add Designation',
    'update_designation' => 'Update Designation'
];
