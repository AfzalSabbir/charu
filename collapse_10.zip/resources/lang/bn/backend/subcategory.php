<?php

return [
    'subcategory' => 'সাব ক্যাটাগরি',
    'subcategory_management' => 'ক্যাটাগরি ব্যবস্থাপনা',
    'edit_category' => 'এডিট ক্যাটাগরি',
    'add_category' => 'নতুন ক্যাটাগরি'
];