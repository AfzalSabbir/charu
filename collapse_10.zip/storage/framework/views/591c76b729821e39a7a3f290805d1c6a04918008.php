<link rel="stylesheet" href="<?php echo e(asset('public/css/vcard-offer.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/printing-offer.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/css/a_custom.css')); ?>"><?php /**PATH E:\xampp\htdocs\charu\resources\views/frontend/partials/styles.blade.php ENDPATH**/ ?>