@extends('frontend.layouts.master')

@section('fav_title', 'Menu')

@section('metas')
@endsection

@section('styles')
@endsection

@section('content')
@endsection

@section('scripts')
@endsection