$(document) .ready(function(){
			$(".aqaq").click(function(){
				$(".navToogle").slideToggle();
				
				
				
				});
		
});
		
		
