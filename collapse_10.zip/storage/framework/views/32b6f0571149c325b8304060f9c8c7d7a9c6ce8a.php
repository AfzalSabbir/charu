<?php
	$created = ucwords(preg_replace("/[\-_]/", " ",  $created));
	$created_ = strtolower(preg_replace("/[\s+]/", "_", $created));
	$created = preg_replace("/[\s+]/", "", $created);
?>
<?php echo $tab; ?>/**<br>
<?php echo $tab; ?>* <strong><?php echo e(ucwords($created)); ?></strong><br>
<?php echo $tab; ?>**/<br>
<?php if($type_ == 'oneClickAll'): ?>
<?php echo $tab; ?>Route::group(['prefix' => '<?php echo e($created_); ?>'], function(){<br>
<?php echo $tab.$tab; ?>Route::get('/', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;index')->name('admin.<?php echo e($created_); ?>.index');<br>
<?php echo $tab.$tab; ?>Route::get('/add', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;add')->name('admin.<?php echo e($created_); ?>.add');<br>
<?php echo $tab.$tab; ?>Route::post('/add', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;store')->name('admin.<?php echo e($created_); ?>.store');<br>
<?php echo $tab.$tab; ?>Route::get('/edit/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;edit')->name('admin.<?php echo e($created_); ?>.edit');<br>
<?php echo $tab.$tab; ?>Route::post('/edit/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;update')->name('admin.<?php echo e($created_); ?>.update');<br>
<?php echo $tab.$tab; ?>Route::get('/delete/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;delete')->name('admin.<?php echo e($created_); ?>.delete');<br>
<?php echo $tab; ?>});<br>

<?php elseif($type_ == 'oneClickAllWithView'): ?>
<?php echo $tab; ?>Route::group(['prefix' => '<?php echo e($created_); ?>'], function(){<br>
<?php echo $tab.$tab; ?>Route::get('/', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;index')->name('admin.<?php echo e($created_); ?>.index');<br>
<?php echo $tab.$tab; ?>Route::get('/add', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;add')->name('admin.<?php echo e($created_); ?>.add');<br>
<?php echo $tab.$tab; ?>Route::post('/add', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;store')->name('admin.<?php echo e($created_); ?>.store');<br>
<?php echo $tab.$tab; ?>Route::get('/view/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;view')->name('admin.<?php echo e($created_); ?>.view');<br>
<?php echo $tab.$tab; ?>Route::get('/edit/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;edit')->name('admin.<?php echo e($created_); ?>.edit');<br>
<?php echo $tab.$tab; ?>Route::post('/edit/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;update')->name('admin.<?php echo e($created_); ?>.update');<br>
<?php echo $tab.$tab; ?>Route::get('/delete/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;delete')->name('admin.<?php echo e($created_); ?>.delete');<br>
<?php echo $tab; ?>});<br>

<?php elseif($type_ == 'modal'): ?>
<?php echo $tab; ?>Route::group(['prefix' => '<?php echo e($created_); ?>'], function(){<br>
<?php echo $tab.$tab; ?>Route::get('/', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;index')->name('admin.<?php echo e($created_); ?>.index');<br>
<?php echo $tab.$tab; ?>Route::post('/add', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;store')->name('admin.<?php echo e($created_); ?>.store');<br>
<?php echo $tab.$tab; ?>Route::post('/edit/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;update')->name('admin.<?php echo e($created_); ?>.update');<br>
<?php echo $tab.$tab; ?>Route::get('/delete/{id}', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;delete')->name('admin.<?php echo e($created_); ?>.delete');<br>
<?php echo $tab; ?>});<br>

<?php else: ?>
<?php echo $tab; ?>Route::group(['prefix' => '<?php echo e($created_); ?>'], function(){<br>
<?php echo $tab.$tab; ?>Route::get('/<strong><?php echo e($created_); ?></strong><?php echo e($type_ == 'index' ? '' : '/'.$type_); ?>', 'Backend\<?php echo e(ucfirst($created)); ?>Controller&commat;<?php echo e($type_); ?>')->name('admin.<?php echo e($created_); ?>.<?php echo e($type_); ?>');<br>
<?php echo $tab; ?>});<br>

<?php endif; ?><?php /**PATH E:\xampp\htdocs\charu\resources\views/backend/pages/root/route.blade.php ENDPATH**/ ?>