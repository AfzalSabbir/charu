<?php

return [
'language_management' => 'Language Management',
'add_name' => 'Add Name',
'developer' => 'Developer',
'language' => 'Language',
'add_file' => 'Add File',
'my_admins' => 'My Admins',
'add_admin' => 'Add Admin',
'all_admin' => 'All Admin',
];
